@extends('app')
@section('content')
	<body>
		<h1>Contact Me</h1>
	</body>

@stop
